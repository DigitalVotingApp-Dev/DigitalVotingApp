I=imread('C:\Program Files\MATLAB\R2016b\bin\Final Project\FingerPrint\Other Datasets\fingerprint_bitmaps\1_1.bmp');
imshow(I)
set(gcf,'position',[1 1 600 600])